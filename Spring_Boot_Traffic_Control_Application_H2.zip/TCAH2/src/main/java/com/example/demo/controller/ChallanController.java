package com.example.demo.controller;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.dao.VehicleRepo;
import com.example.demo.model.Vehicle;
import com.example.demo.service.ChallanService;

@Controller
public class ChallanController
{
	
        
	     @Autowired
          VehicleRepo repo;

		 @RequestMapping("/vehicleNumberForm")
	
		public String vehicleNumberForm()
		{
			return "vehicleNumberForm";
		}
		
		@RequestMapping("/showChallanAmount")
	
		public ModelAndView showChallanAmount(@RequestParam("vehiclenumber") int vehicleNumber)
		{
			ModelAndView mv = new ModelAndView();
		      
		      Optional<Vehicle> v = repo.findById(vehicleNumber);
			
		    mv.addObject("Vehicle",v);
		    mv.setViewName("showChallanAmount");
		    return mv;
		}
		
		@RequestMapping("/payChallanAmount")
	
		public String payChallan()
		{
			
			return "paymentSuccessful";
		}
}
