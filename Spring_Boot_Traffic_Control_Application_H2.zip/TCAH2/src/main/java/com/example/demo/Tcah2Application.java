package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.model.Vehicle;
import com.example.demo.service.ChallanService;

@SpringBootApplication
public class Tcah2Application {

	public static void main(String[] args) 
	{
		SpringApplication.run(Tcah2Application.class, args);
		Vehicle v = null;
		ChallanService c = new ChallanService();
		v=c.findVehicle(1);
		System.out.println(v.getVehicleName());
	}

}
