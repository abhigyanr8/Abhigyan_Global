insert into vehicle values (1111,1000,'Indica');
insert into vehicle values (2222,2000,'Indigo');
insert into vehicle values (3333,4000,'Safari');