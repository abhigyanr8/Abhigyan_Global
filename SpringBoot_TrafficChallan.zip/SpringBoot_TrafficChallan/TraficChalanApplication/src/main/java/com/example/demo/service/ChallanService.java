package com.example.demo.service;

import java.util.ArrayList;

import com.example.demo.model.Vehicle;

public class ChallanService 
{
	ArrayList<Vehicle> vehicleList = new ArrayList<Vehicle>();

	public ChallanService() 
	{
		vehicleList.add(new Vehicle(1111,1000,"Indica"));
		vehicleList.add(new Vehicle(2222,2000,"Indigo"));
		vehicleList.add(new Vehicle(3333,3000,"Safari"));
	}
	
	public Vehicle findVehicle(int vehicleNumber)
	{
		Vehicle vh = null;
		for(Vehicle v : vehicleList)
		{
			if(v.getVehicleNumber()==vehicleNumber)
			{
				vh=v;
				break;
			}
		}
		return vh;
	}
	

}
