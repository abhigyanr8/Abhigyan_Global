package com.example.demo.model;

public class Vehicle 
{
	private int vehicleNumber;
	private int challanAmount;
	private String vehicleName;
	public int getVehicleNumber() {
		return vehicleNumber;
	}
	public void setVehicleNumber(int vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}
	public Vehicle(int vehicleNumber, int challanAmount, String vehicleName) {
		super();
		this.vehicleNumber = vehicleNumber;
		this.challanAmount = challanAmount;
		this.vehicleName = vehicleName;
	}
	public int getChallanAmount() {
		return challanAmount;
	}
	public void setChallanAmount(int challanAmount) {
		this.challanAmount = challanAmount;
	}
	public String getVehicleName() {
		return vehicleName;
	}
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}
	

}
