package com.cts.irctc.controller;

import java.sql.Date;
import java.time.LocalDate;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cts.irctc.exception.ApplicationException;
import com.cts.irctc.model.TicketBooking;
import com.cts.irctc.model.TrainInfo;
import com.cts.irctc.service.IrctcService;
import com.google.common.base.Objects;

@Controller
public class IrctcController {
	private IrctcService service;

	
	@Autowired
	public IrctcController(IrctcService service) {
		super();
		this.service = service;
	}

 //Ticket Booking Page
	
	@RequestMapping("/showTicketBookingForm")
	public String showTicketBookingForm() 
	{
		return "ticketBooking"; 
	}
//Booking Form Validation and Result Page
	
	@RequestMapping("/getTicketBookingResultPage")
	public String getCarSearchResultForm(@Valid TicketBooking ticketBooking,BindingResult result,ModelMap map) throws ApplicationException 
	  {
		if(result.hasErrors())
	        return "ticketBooking";
		else
		{
			if(ticketBooking.getFromCity().contentEquals(ticketBooking.getToCity()))
				return "error";
		else
			{
		      map.addAttribute("ticketBooking",ticketBooking);
		      
		      if(service.getTicketBookingResult(ticketBooking)==null)  //If train not available
		    	  return "trainNotAvailable";
		      
		      map.addAttribute("pnr",service.getPNRNumber(ticketBooking));
		      map.addAttribute("trainInfo",service.getTicketBookingResult(ticketBooking));
		      LocalDate today = LocalDate.now();
		      LocalDate tomorrow = today.plusDays(1);
		      map.addAttribute("date",tomorrow);
		      int fareamount= (int) (ticketBooking.getNoOfTickets()*service.getTicketBookingResult(ticketBooking).getFarePerPassenger());
		      map.addAttribute("fareamount",fareamount);
		         return "ticketBookingResult";
			}
		}
	  }  
	
	
	public List<String> populateFromCities() {
		List<String> fromCities = new ArrayList<String>();

		 fromCities.add("Chennai"); 
		  fromCities.add("Delhi"); 
		  fromCities.add("Bangalore"); 
		  fromCities.add("Pune");
				
		return fromCities;
	}
	
	
	public List<String> populateToCities() {
		List<String> toCities = new ArrayList<String>();
		 
		  toCities.add("Chennai"); 
		  toCities.add("Delhi");
		  toCities.add("Bangalore"); 
		  toCities.add("Pune");		 	
		
		return toCities;
	}
	
	
	public List<String> populateClassType() {
		List<String> classTypes = new ArrayList<String>();
		  
		 classTypes.add("AC First Class (1A)");
		  classTypes.add("AC 2 Tier (2A)"); 
		  classTypes.add("AC 3 Tier (3A)");
		  classTypes.add("Sleeper (SL)"); 
		  classTypes.add("Second Sitting (2S)"); 
		  
			
		return classTypes;
	}
	
	
}
