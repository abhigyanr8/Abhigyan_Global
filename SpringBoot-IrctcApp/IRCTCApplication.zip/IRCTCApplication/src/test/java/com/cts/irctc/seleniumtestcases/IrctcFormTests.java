package com.cts.irctc.seleniumtestcases;

import static org.junit.Assert.assertNotNull;

import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class IrctcFormTests {
	static WebDriver driver;

	static String appPath = "http://localhost:5050/showTicketBookingForm";
	static String appPathWithPort = "http://localhost:5050/";
	SoftAssert sa=null;
	
	@BeforeTest
	public void beforeTest() {
		System.setProperty("webdriver.gecko.driver", "src\\drivers\\geckodriver.exe");

		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setCapability("marionette", true);
		driver = new FirefoxDriver(capabilities);

		driver.get(appPath);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		sa=new SoftAssert();
	}
	@AfterTest
	public void afterTest() {
		driver.close();
	}
	
	@Test(priority = 1)
	public void testheadingPresent() {
		WebElement heading = driver.findElement(By.id("heading"));
		sa.assertEquals(heading.getText(),"Indian Railway System","Heading text failed ");
		sa.assertAll();
	}
   
	@Test(priority = 2)
	public void testcustomerNamePresentsTagNameType() {
		WebElement customerName = driver.findElement(By.id("customerName"));
		sa.assertNotNull(customerName,"Customer Name element/id not found ");
		sa.assertEquals(customerName.getTagName(),"input","Customer Name element not found ");
		sa.assertEquals(customerName.getAttribute("type"),"text","Customer name element input type failed ");
		sa.assertAll();
	}
	@Test(priority = 3)
	public void testmobileNumberPresentsTagNameType() {
		WebElement mobileNumber = driver.findElement(By.id("mobileNumber"));
		sa.assertNotNull(mobileNumber,"Mobile number element/id not found ");
		sa.assertEquals(mobileNumber.getTagName(),"input", "Mobile number element not found ");
		sa.assertEquals(mobileNumber.getAttribute("type"),"text", "Mobile number element input type failed ");
		sa.assertAll();
	}
	@Test(priority = 4)
	public void testFromCityPresentsTagNameType() {
		WebElement fromCity = driver.findElement(By.id("fromCity"));
		sa.assertNotNull(fromCity,"From city element/id not found ");
		sa.assertEquals(fromCity.getTagName(),"select", "From city element not found ");
		sa.assertAll();
	}
	@Test(priority = 5)
	public void testToCityPresentsTagNameType() {
		WebElement toCity = driver.findElement(By.id("toCity"));
		sa.assertNotNull(toCity,"To city element/id not found ");
		sa.assertEquals(toCity.getTagName(),"select", "To city element not found ");
		sa.assertAll();
	}
	@Test(priority = 6)
	public void testTravelClassPresentsTagNameType() {
		WebElement travelClass = driver.findElement(By.id("travelClass"));
		sa.assertNotNull(travelClass,"Travel class element/id not found ");
		sa.assertEquals(travelClass.getTagName(),"select", "Travel class element not found ");
		sa.assertAll();
	}
	@Test(priority = 7)
	public void testNoOfTicketsPresentsTagNameType() {
		WebElement noOfTickets = driver.findElement(By.id("noOfTickets"));
		sa.assertNotNull(noOfTickets,"No Of Tickets element/id not found ");
		sa.assertEquals(noOfTickets.getTagName(),"input", "No Of Tickets element not found ");
		sa.assertAll();
	}
	@Test(priority = 8)
	public void testsubmitPresentsTagNameType() {

		WebElement book = driver.findElement(By.name("submit"));
		sa.assertNotNull(book,"Book submit button/id not found ");
		sa.assertEquals(book.getTagName(),"input","Book submit button not found ");
		sa.assertEquals(book.getAttribute("type"),"submit","Book submit button input type failed ");
		sa.assertEquals(book.getAttribute("value"),"Book", "Book submit button lable failed" );
		sa.assertAll();
	}
	@Test(priority = 9)
	public void testFormPresentActionValueMethodName() {
		WebElement myform = driver.findElement(By.name("form"));
		sa.assertNotNull(myform,"Form element/id not found");
		sa.assertEquals(myform.getAttribute("action"),appPathWithPort + "getTicketBookingResultPage","Form action value failed ");
		sa.assertEquals(myform.getAttribute("method"),"post","Form method value failed ");
		sa.assertAll();
	}
	@Test(priority = 10)
	public void testcustomerNameEmpty() {

		driver.findElement(By.id("customerName")).sendKeys("");
		driver.findElement(By.name("submit")).click();
		String expectedMsg = "Customer name is required";
		String actualMsg = driver.findElement(By.xpath("//*[@id=\'customerName.errors\']")).getText();
		sa.assertEquals(actualMsg, expectedMsg,"Customer name validation message failed ");
		sa.assertAll();
	}
	@Test(priority = 11)
	public void testmobileNumberWrong() {

		driver.findElement(By.id("mobileNumber")).sendKeys("0");
		driver.findElement(By.name("submit")).click();
		String expectedMsg = "Mobile number should be 10 digits and starting with digit 7/8/9";

		String text = driver.findElement(By.xpath("//*[@id=\'mobileNumber.errors\']")).getText();
		sa.assertEquals(expectedMsg, text);
		sa.assertAll();
	}
	@Test(priority = 12)
	public void testmobileNumberWrong1() {

		driver.findElement(By.id("mobileNumber")).sendKeys("1234567890");
		driver.findElement(By.name("submit")).click();
		String expectedMsg = "Mobile number should be 10 digits and starting with digit 7/8/9";

		String text = driver.findElement(By.xpath("//*[@id=\'mobileNumber.errors\']")).getText();
		sa.assertEquals(text,expectedMsg,"Mobile number validation message failed ");
		sa.assertAll();
	}
	@Test(priority = 13)
	public void testFromCity() {
		String[] cityNames = { "Chennai", "Delhi", "Bangalore", "Pune" };
		Select selectCity = new Select(driver.findElement(By.id("fromCity")));
		List<WebElement> cityDropDown = selectCity.getOptions();
		for (int k = 0; k < cityDropDown.size() - 1; k++) {
			sa.assertEquals(cityNames[k], cityDropDown.get(k).getText());
		} // for
		sa.assertAll("From city names in dropdown are not as per requirement ");
	}
	@Test(priority = 14)
	public void testToCity() {
		String[] cityNames = { "Chennai", "Delhi", "Bangalore", "Pune" };
		Select selectCity = new Select(driver.findElement(By.id("toCity")));
		List<WebElement> cityDropDown = selectCity.getOptions();
		for (int k = 0; k < cityDropDown.size() - 1; k++) {
			sa.assertEquals(cityNames[k], cityDropDown.get(k).getText());
		} // for
		sa.assertAll("To city names in dropdown are not as per requirement ");
	}
	
	@Test(priority = 15)
	public void testTravelClass() {
		String[] travelClassNames = {"AC First Class (1A)", "AC 2 Tier (2A)", "AC 3 Tier (3A)", "Sleeper (SL)", "Second Sitting (2S)" };
		Select travelClass = new Select(driver.findElement(By.id("travelClass")));
		List<WebElement> travelClassDropDown = travelClass.getOptions();
		for (int k = 0; k < travelClassDropDown.size() - 1; k++) {
			sa.assertEquals(travelClassNames[k], travelClassDropDown.get(k).getText());
		} // for
		sa.assertAll("Travel Class Names in dropdown are not as per requirement ");
	}
	@Test(priority = 16)
	public void testNoOfTicketsWrong1() {

		driver.findElement(By.id("noOfTickets")).sendKeys("0");
		driver.findElement(By.name("submit")).click();
		String expectedMsg = "No. of tickets must be more than 0";

		String text = driver.findElement(By.xpath("//*[@id=\'noOfTickets.errors\']")).getText();
		sa.assertEquals(expectedMsg, text);
		sa.assertAll();
	}
	@Test(priority = 17)
	public void testNoOfTicketsWrong2() {

		driver.findElement(By.id("noOfTickets")).sendKeys("5");
		driver.findElement(By.name("submit")).click();
		String expectedMsg = "No. of tickets must be less than 5";

		String text = driver.findElement(By.xpath("//*[@id=\'noOfTickets.errors\']")).getText();
		sa.assertEquals(expectedMsg, text);
		sa.assertAll();
	}
	@Test(priority = 18)
	public void testSubmitActionForSameFromAndToCity() {
		driver.findElement(By.id("customerName")).sendKeys("John");
		driver.findElement(By.id("mobileNumber")).clear();
		driver.findElement(By.id("mobileNumber")).sendKeys("8834567890");
		
		driver.findElement(By.id("fromCity")).sendKeys("Pune");
		driver.findElement(By.id("toCity")).sendKeys("Pune");
		driver.findElement(By.id("travelClass")).sendKeys("AC First Class (1A)");
		driver.findElement(By.id("noOfTickets")).clear();
		driver.findElement(By.id("noOfTickets")).sendKeys("2");

		// check error.jsp page opens here with error message
		driver.findElement(By.name("submit")).click();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("error"))));
		String resultText = driver.findElement(By.xpath("//h3[1]")).getText();
		String resultText1 = driver.findElement(By.xpath("//h3[2]")).getText();
		String resultText2 = driver.findElement(By.xpath("//h3[3]")).getText();
		//
		WebElement searchResult = driver.findElement(By.id("error"));
		sa.assertNotNull(resultText,"Error message heading not found ");
		sa.assertEquals(resultText ,"Unable to book ticket. Below are the error details:","Error message failed ");
		sa.assertNotNull(resultText1,"Error message heading not found ");
		sa.assertEquals(resultText1, "Response Code : 400","Error message failed ");
		sa.assertNotNull(resultText2,"Error message heading not found ");
		sa.assertEquals(resultText2, "Error Message : From and to city can't be same","Error message failed ");  
		
		// check hyperlink available -

		WebElement link = driver.findElement(By.id("bookTicket"));
		sa.assertNotNull(link,"Book Ticket link element/id not found ");
		sa.assertEquals(link.getTagName(),"a", "Book Ticket link element not found "); 
		// check href value
		sa.assertTrue(link.getAttribute("href").equals("http://localhost:5050/showTicketBookingForm"),"Book Ticket link element href value failed "); 
		// click hyperlink
		driver.findElement(By.id("bookTicket")).click();
		sa.assertAll();
	}
	@Test(priority = 19)
	public void testSubmitActionWithTicketBookingResult() {
		driver.findElement(By.id("customerName")).clear();
		driver.findElement(By.id("customerName")).sendKeys("John");
		driver.findElement(By.id("mobileNumber")).clear();
		driver.findElement(By.id("mobileNumber")).sendKeys("8834567890");
		
		driver.findElement(By.id("fromCity")).sendKeys("Chennai");
		driver.findElement(By.id("toCity")).sendKeys("Bangalore");
		driver.findElement(By.id("travelClass")).sendKeys("Sleeper (SL)");
		driver.findElement(By.id("noOfTickets")).clear();
		driver.findElement(By.id("noOfTickets")).sendKeys("2");
		driver.findElement(By.name("submit")).click();
		
		// check result page opens or not
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("ticket"))));
		String resultText = driver.findElement(By.xpath("//h3[1]")).getText();

		WebElement searchResult = driver.findElement(By.id("ticket"));
		sa.assertNotNull(resultText,"ticket element/id not found");
		sa.assertEquals(resultText, "Congratulations, your ticket got booked!!","Ticket booking result page heading text failed ");
		// check table -first row ,first column
		String resultText1 = driver.findElement(By.xpath("//table[1]")).findElement(By.xpath("//tr[1]"))
				.findElement(By.xpath("//td[1]")).getText();
		assertNotNull(resultText1,"Ticket booking result page table heading not found ");
		sa.assertEquals(resultText1,"PNR Number:","Ticket booking result page table first column heading text failed ");

		// check table -first row ,second column
		String resultText2 = driver.findElement(By.xpath("//table[1]")).findElement(By.xpath("//tr[1]"))
				.findElement(By.xpath("//td[2]")).getText();
		sa.assertNotNull(resultText2,"PNR number not found  ");
		sa.assertEquals(resultText2,"022-8834567","PNR number value failed ");

		//check table second row , first column /html/body/table/tbody/tr[2]/td[1]
		String resultText3 = driver.findElement(By.xpath("//html/body/table/tbody/tr[2]/td[1]")).getText();
		sa.assertNotNull(resultText3,"Ticket booking result page table heading not found ");
		sa.assertEquals(resultText3,"Train Number:","Ticket booking result page table first column heading text failed ");

		//check table second row , second column
		String resultText4 = driver.findElement(By.xpath("//html/body/table/tbody/tr[2]/td[2]")).getText();
		sa.assertNotNull(resultText4,"Train number not found ");
		sa.assertEquals(resultText4,"02296","Train number value failed ");
		
		//check date of travel- 4th row 1st column
		String resultText41 = driver.findElement(By.xpath("//html/body/table/tbody/tr[4]/td[1]")).getText();
		sa.assertNotNull(resultText41,"Ticket booking result page table heading not found ");
		sa.assertEquals(resultText41,"Date Of Travel:","Ticket booking result page table first column heading text failed ");
		
		//check date of travel value- 4th row 1st column
		//convert date to string
		String tommorowDate=LocalDate.now().plusDays(1).toString();
		String resultText42 = driver.findElement(By.xpath("//html/body/table/tbody/tr[4]/td[2]")).getText();
		sa.assertNotNull(resultText42,"Date of Travel not found");
		sa.assertEquals(resultText42,tommorowDate,"Date of Travel value failed ");
		
		
		//check table 8th row, first column
		String resultText5 = driver.findElement(By.xpath("//html/body/table/tbody/tr[8]/td[1]")).getText();
		assertNotNull(resultText5,"Ticket booking result page table heading not found ");
		sa.assertEquals(resultText5,"Total Fare Amount:","Ticket booking result page table first column heading text failed ");
		
		//check table 8th row, second column
		String resultText6 =driver.findElement(By.xpath("//html/body/table/tbody/tr[8]/td[2]")).getText(); 
		sa.assertNotNull(resultText6,"Total Fare Amount not found ");
		sa.assertEquals(resultText6,"530.0","Total Fare Amount value failed ");
		
	
		// check hyperlink available -

		WebElement link = driver.findElement(By.id("bookTicket"));
		sa.assertNotNull(link,"book Ticket link/id not found ");
		sa.assertEquals(link.getTagName(),"a","book Ticket link not found"); 
		// check href value
		sa.assertTrue(link.getAttribute("href").equals("http://localhost:5050/showTicketBookingForm"),"Book ticket link href value failed "); 
		// click hyperlink																									
		driver.findElement(By.id("bookTicket")).click();
		sa.assertAll();
	}
	
	@Test(priority = 20)
	public void testSubmitActionWithTrainNotFound1() {
		driver.findElement(By.id("customerName")).clear();
		driver.findElement(By.id("customerName")).sendKeys("John");
		driver.findElement(By.id("mobileNumber")).clear();
		driver.findElement(By.id("mobileNumber")).sendKeys("8834567890");
		
		driver.findElement(By.id("fromCity")).sendKeys("Pune");
		driver.findElement(By.id("toCity")).sendKeys("Chennai");
		driver.findElement(By.id("travelClass")).sendKeys("Sleeper (SL)");
		driver.findElement(By.id("noOfTickets")).clear();
		driver.findElement(By.id("noOfTickets")).sendKeys("2");
		driver.findElement(By.name("submit")).click();

		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("noResult"))));
		String resultText = driver.findElement(By.id("noResult")).getText();

		// WebElement searchResult = driver.findElement(By.id("noResult"));
		sa.assertNotNull(resultText,"noResult element/id not found");
		sa.assertEquals(resultText,"Sorry, currently no train available for given details!!!","train not found message failed ");

		// check hyperlink available 		
		WebElement link = driver.findElement(By.id("bookTicket"));
		sa.assertNotNull(link,"Book Different Ticket link/id not found " );
		sa.assertEquals(link.getTagName(),"a","Book Different Ticket link not found "); // check href value
		sa.assertTrue(link.getAttribute("href").equals("http://localhost:5050/showTicketBookingForm"),"Book Different Ticket link href value failed "); // click hyperlink
																									// click
		driver.findElement(By.id("bookTicket")).click();
		sa.assertAll();
	}
	
	@Test(priority = 21)
	public void testSubmitActionWithTrainNotFound2() {
		driver.findElement(By.id("customerName")).clear();
		driver.findElement(By.id("customerName")).sendKeys("John");
		driver.findElement(By.id("mobileNumber")).clear();
		driver.findElement(By.id("mobileNumber")).sendKeys("8834567890");
		
		driver.findElement(By.id("fromCity")).sendKeys("Chennai");
		driver.findElement(By.id("toCity")).sendKeys("Bangalore");
		driver.findElement(By.id("travelClass")).sendKeys("AC First Class (1A)");
		driver.findElement(By.id("noOfTickets")).clear();
		driver.findElement(By.id("noOfTickets")).sendKeys("2");
		driver.findElement(By.name("submit")).click();

		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("noResult"))));
		String resultText = driver.findElement(By.id("noResult")).getText();

		// WebElement searchResult = driver.findElement(By.id("noResult"));
		sa.assertNotNull(resultText,"noResult element/id not found");
		sa.assertEquals(resultText,"Sorry, currently no train available for given details!!!","train not found message failed ");

		// check hyperlink available 		
		WebElement link = driver.findElement(By.id("bookTicket"));
		sa.assertNotNull(link,"Book Different Ticket link/id not found " );
		sa.assertEquals(link.getTagName(),"a","Book Different Ticket link not found "); // check href value
		sa.assertTrue(link.getAttribute("href").equals("http://localhost:5050/showTicketBookingForm"),"Book Different Ticket link href value failed "); // click hyperlink
																									// click
		driver.findElement(By.id("bookTicket")).click();
		sa.assertAll();
	}

}
